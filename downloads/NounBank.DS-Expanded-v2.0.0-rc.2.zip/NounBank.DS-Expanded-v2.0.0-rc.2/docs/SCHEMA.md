# Release schema

`data/lemmas/*.json` is the primary per-lemma distribution surface. Each file contains lexical provenance, observed exact semantic units, all evaluated DANTEStocks occurrences, WSD state for `S` occurrences, English NomBank alignment when licensed, and argument-role decisions for regular eligible instances.

`CONTEXTUAL_INSTANCE_AUTHORITY_6416.tsv` is the complete evaluated occurrence census. `N` occurrences are retained as terminal contextual exclusions.

`TERMINAL_SEMANTIC_EXCEPTIONS_94.tsv` preserves the exact non-regular semantic population and must not be interpreted as missing data.

HEAD and SPAN are separate fields. Every `YES` role realization has both. `ABSTAIN` is a typed terminal decision, not generic unresolved.
