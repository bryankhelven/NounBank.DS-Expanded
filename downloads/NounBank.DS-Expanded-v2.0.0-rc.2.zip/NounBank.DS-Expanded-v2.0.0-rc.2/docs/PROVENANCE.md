# Provenance and lineage

- Authority current ACK: `ORCH_RECON_000155`
- Main state: `STATE_000027`
- V1 exact historical authority: commit `d21f2fd6ef6d0c19c88af40d2a3284ea892dc6c9`, archive SHA-256 `e6bd4572dcedecd1225d42db5748f8b49f65f90c33b3ac6b3e3b37465f80888a`.
- Current lexical additions authority: exact recovered 564-row ledger SHA-256 `565ead29bdace4c52f39e75f3af2bf23bbe02b91fd1dd5b6d4b89d3d8a11f9d7`.
- Current contextual projection: 6,416 rows, deterministic lineage `ORCH40_6406 + V1DELTA001_10_RECOVERED - 2_OLD_TRADE_S_TO_N_UNDER_DAYTRADE_IDENTITY_REPAIR`.
- WSD: terminal master 3,618 after exhaustive readjudication.
- ENMAP: `ORCH_RECON_000150`.
- Licensed role inventory: `ORCH_RECON_000151`.
- Combined argument authority: accepted/frozen by `ORCH_RECON_000155`.

The historical four-row `OTHER_CLOSED_AUTHORITY` label is not used as current primary authority. `analista-chefe`, `diretor-executivo`, `ex-diretor`, and `queridinho` are projected under current `DUPB_ADJUDICATED_DERIVED_AUTHORITY`, yielding the frozen 295 DUPB-backed + 269 LeGOS-only partition for the 564 additions.
