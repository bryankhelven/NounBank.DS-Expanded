# NounBank.DS Expanded — v2.0.0-rc.2

Release candidate assembled under `ORCH_RECON_000155` from frozen `NBE_V2_F` authorities.

## Scope

- Target corpus: **DANTEStocks only**.
- 709 lexical entries: 145 inherited from published NounBank.DS V1 and 564 additions.
- 6,416 evaluated nominal occurrences: 3,618 contextual predicators (`S`) and 2,798 contextual non-predicators (`N`).
- 3,595 exact WSD bindings and 23 typed terminal non-exact cases.
- 3,524 instances in the regular argument resource, with 14,984 licensed role slots.
- 2,669 realized arguments with distinct HEAD and SPAN.

The 94 semantic exceptions are preserved explicitly rather than forced into the regular pipeline: 23 WSD non-exact, 52 English-NomBank non-aligned, and 19 construction-specific.

## Provenance firewall

The release preserves V1 reuse, identity repairs, inherited-new annotations, and new-564 annotations as distinct lineage. Porttinari is not row-level authority for this resource.
