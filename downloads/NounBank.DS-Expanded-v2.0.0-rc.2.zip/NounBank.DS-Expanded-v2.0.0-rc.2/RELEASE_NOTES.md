# Release notes — v2.0.0-rc.2

This candidate supersedes invalidated historical Expanded release claims. It is assembled from the corrective NBE_V2 authority chain and does not reuse ORCH115 relation counts as gold.

Scientific layers are frozen independently and retain typed terminal exceptions rather than being forced for coverage.
